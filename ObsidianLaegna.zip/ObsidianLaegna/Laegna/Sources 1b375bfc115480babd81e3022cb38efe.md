# Sources

Here is some content, which is useful in understanding Laegna theories.

[Kybalion - Chapter 4 and 7 The All](Sources/Kybalion%20-%20Chapter%204%20and%207%20The%20All%201b375bfc115480b8a1dad00e8792781e.md)

[Kybalion](Sources/Kybalion%201b475bfc115480f987a4d4f65b0fe15b.md)

[Proof of "Mind" in Buddhism: The Eternal Deed Beyond Time](Sources/Proof%20of%20Mind%20in%20Buddhism%20The%20Eternal%20Deed%20Beyond%20%201b475bfc115480f3a342d6a8ca9f8a1c.md)

[**Introduction: The Unification of Mind, Self, and Evolution**](Sources/Introduction%20The%20Unification%20of%20Mind,%20Self,%20and%20Ev%201b575bfc11548086b7fcec5b1b9e9922.md)