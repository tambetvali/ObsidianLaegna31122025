# Strings

If a struct is defined with list of Tens, it becomes digital number.

Empty digits like spaces mean that no information bit is passed, logic to choose value for this Ten does not exist. This is replacement for Zero, which is kind of “taboo” in Laegna for mystical reasons well 🏋🏼

This struct, such as:

Float: Ten[10]

Now there is 10 Tens, including the basic combinatorics, but the whole component is considered to be whole number.

[Ten - the base-4 bit of Logex Automation](Strings/Ten%20-%20the%20base-4%20bit%20of%20Logex%20Automation%201b475bfc11548093aae0e0f77fe3f2b7.md)