# Personal Human Ponegate

How the ponegate, especially posetive and negotive values, would work in context of human persons in singular approach, private lives of them.

While we talk about archetypes of the personal life, not only “*positive*” (position or posetion) and “*negative*” (negation or negotion) binary values should be considered, but rather we can analyze these stories about the sign - several articles here are about this.

***The Conflict of Authority, Power, and the Opposite Realities: A Psychological and Legal Exploration*** - here you can see negotion and posetion, as well as position and negation ponegating in a personal stories.

[Positivist panic with enlightenment](Personal%20Human%20Ponegate/Positivist%20panic%20with%20enlightenment%201a675bfc11548006838bc537bdb41843.md)

[Is this an argument that you cannot do anything?](Personal%20Human%20Ponegate/Is%20this%20an%20argument%20that%20you%20cannot%20do%20anything%201a575bfc11548075b8e4ff3905ff877a.md)

[Hallucinogenic materialist street fighters](Personal%20Human%20Ponegate/Hallucinogenic%20materialist%20street%20fighters%201a575bfc115480b1be88c4bf34ce8090.md)

[Metaphysics of a Human, Life and Lifelike Structures](Personal%20Human%20Ponegate/Metaphysics%20of%20a%20Human,%20Life%20and%20Lifelike%20Structur%201a575bfc115480c4a838fcef7b416072.md)