# Returners

Update: it’s very sad if someone is lift up, but then down ..when world is changing, you can have anti-enlightenment, where the correct images in your head are suddenly insanity, a trash you have to collect but cannot before you have a better one.

Buddha named the ones, who are not going to be born back into this world, "non-returners". I want to show you which are "returners" - but they return to lower world inside this world, being at higher loka, they are later in lower one.

Sometimes I meet people, who seem spiritually very advanced, but later they wall back - into the loka of common people (loka is like a dimension you live in or happen to be sometimes - the same place, but it seems completely different, and you happen to meet different people and get different experience; your realm or plane of existence can change without physical environment changing). They are initially like enlightened - but later, they become completely mundane.

The returners initially:

- Their aura, mental condition, communication and level of wisdom are very perfect, they seem perfectly enlightened.
- You can, if you really try, find out some weakness and emptiness in their aura.

Over time, something happens (usually preceded by the fact that you see some materialist people around them with conspiracy feeling, running around and creating up a theme):

- Their speech becomes materialist, the good feeling is gone and aura is broken.
- They get considerably older - even if they are 23, suddenly they look kind of old; before they looked perfectly young.
- They have trouble with spiritual picture, which they perfectly understood before, and they make materialist speeches.
- It seems that the person is replaced - you get a strong feeling that somebody took your friend away and did put the other person there. This has to do with the fact that person who we are, it's their identity code - if it's not the same any more, then it's not the same person; the person is dead. Initially, I really had doubts in many cases, whether it's the same person.
- They have sudden loss of memory - they do not remember an important, magical thing happening with you two together, at all. They might lose a long series of conversations. Possibly, those happened with another person - they share some material memories, where they are the same, but not the information about spiritual heightened states, which happened to their "enlightened self" only.
- You get a feeling about them, that they are like trash. Before they felt like gods, with strong feeling of worthiness, but now they feel like trash - like they do not have a self-worth anymore.
- They put lots of talk and effort into their material things; like going to shop or washing the dishes. The feeling of responsibility is connected to suppressing their spiritual selves - like those two were in contradiction. But they did all those things before as well - going to shop, definitely, is quite easy for a spiritual person.
- The spiritual information they got, the distorted way they pass it to people now, might feel like betrayal; it's good that they lost so many memories - maybe they would start a real conspiracy with those, for example taking something magical to scientific research (you won't put a mermaid under the knives of clinical research of show it in a circus).

One time I have seen a mass return - I saw a whole connected circle of people, who felt like Sanga for me, suddenly becoming totally materialist and losing the memories and powers they had. I felt a deep heartfelt loss.

Non-returner is a person, who has first-hand experience with three truths, of which they are aware and thus have the seed of enlightenment deeply within, as a clear personal knowledge. So the returner - one, who has happened to walk a spiritual road, but without this deep insight. Often they continue to walk it, but you never get a true experience back with them.