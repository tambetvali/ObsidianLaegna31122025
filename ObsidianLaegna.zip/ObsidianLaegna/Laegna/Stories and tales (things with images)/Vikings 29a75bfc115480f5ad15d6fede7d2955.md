# Vikings

![magicstudio-art (15).jpg](Vikings/magicstudio-art_(15).jpg)

[**The Call of Valhalla: The Science of the Shadow**
Written by chatgpt for half-fantasy half-experience/interpretation story related to my actual physical experience, but removing real people and places.](Vikings/The%20Call%20of%20Valhalla%20The%20Science%20of%20the%20Shadow%20Wri%2029975bfc115480268808ced744ea905c.md)

[if vikings met jesus and brought his culture, united the heart of christ with hand of thor: did they become celts, being christian jewish vikings, and create swedish christian empire as a consequence? how viking thinks about this?](Vikings/if%20vikings%20met%20jesus%20and%20brought%20his%20culture,%20unit%2029975bfc11548063bfd7fd4bde457fda.md)

[Viking and Christ](Vikings/Viking%20and%20Christ%2029975bfc115480548f1df02c48e03113.md)

[Philosophical thoughts on Vikings](Vikings/Philosophical%20thoughts%20on%20Vikings%2029a75bfc1154805da16dc7743c768654.md)