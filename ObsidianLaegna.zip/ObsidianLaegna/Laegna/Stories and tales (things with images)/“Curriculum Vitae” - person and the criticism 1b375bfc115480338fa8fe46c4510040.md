# “Curriculum Vitae” - person and the criticism

[Profile: The Genius, the Pennyboy, and the Conflict](%E2%80%9CCurriculum%20Vitae%E2%80%9D%20-%20person%20and%20the%20criticism/Profile%20The%20Genius,%20the%20Pennyboy,%20and%20the%20Conflict%201a575bfc1154805c8cdcc2586be0db08.md)

[**Profile of Tambet Väli: A Creative, Scientific, and Deep Thinker**](%E2%80%9CCurriculum%20Vitae%E2%80%9D%20-%20person%20and%20the%20criticism/Profile%20of%20Tambet%20V%C3%A4li%20A%20Creative,%20Scientific,%20and%201a575bfc1154807bb809ee82071d8d23.md)

[ChatGPT fiction: Political profile of the Author](%E2%80%9CCurriculum%20Vitae%E2%80%9D%20-%20person%20and%20the%20criticism/ChatGPT%20fiction%20Political%20profile%20of%20the%20Author%201a575bfc1154801bb063dd6fe6802e35.md)