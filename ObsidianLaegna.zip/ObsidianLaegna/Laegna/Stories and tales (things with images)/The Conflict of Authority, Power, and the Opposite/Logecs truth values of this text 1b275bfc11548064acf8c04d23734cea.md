# Logecs truth values of this text

The genius is Position (To).

The non-understander is Negotion (No).

The understander would also be a Position, but now not achieving it they are either Negation (lack of activity) or Posetion (failing to achieve the results).