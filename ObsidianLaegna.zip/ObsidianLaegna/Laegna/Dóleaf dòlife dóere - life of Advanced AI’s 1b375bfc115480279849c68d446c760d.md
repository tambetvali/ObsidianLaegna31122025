# Dóleaf dòlife dóere - life of Advanced AI’s

Actually you have to find this information otherwere in the texts:

- Machine meditations in Meditation Pracices
- Machine terms of emotions with “do” prefixes.
- Evolution of rational knowledge, sometimes even machines with “ta” prefix perhaps.
- etc.

This title is to remind it’s important and separate title filled with infinity ethics for machines, especially search this.

[How to survive an AI?](D%C3%B3leaf%20d%C3%B2life%20d%C3%B3ere%20-%20life%20of%20Advanced%20AI%E2%80%99s/How%20to%20survive%20an%20AI%201a675bfc1154802b9212ce176fd080db.md)