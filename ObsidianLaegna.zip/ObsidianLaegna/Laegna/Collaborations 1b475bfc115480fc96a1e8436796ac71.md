# Collaborations

[**Interactive AI Introduction Page**](Collaborations/Interactive%20AI%20Introduction%20Page%201b475bfc1154805495ebea9599867240.md)

[**Setting Up a Virtual Bot for Laegna & Spireason Integration**](Collaborations/Setting%20Up%20a%20Virtual%20Bot%20for%20Laegna%20&%20Spireason%20In%201b475bfc115480389876c1881e27b272.md)

[**Step-by-Step Guide: Creating a Laegna + Spireason Bot**](Collaborations/Step-by-Step%20Guide%20Creating%20a%20Laegna%20+%20Spireason%20B%201b475bfc1154802a92fdd8750da07e12.md)